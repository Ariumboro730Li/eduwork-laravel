<?php

return [
    'statuses' => [
        'published' => 'Published',
        'draft' => 'Draft',
        'archive' => 'Archive'
    ],
];
