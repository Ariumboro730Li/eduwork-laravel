@auth
    @include('layouts.navbars.navs.auth')
@else
    @include('layouts.navbars.navs.guest')
@endauth