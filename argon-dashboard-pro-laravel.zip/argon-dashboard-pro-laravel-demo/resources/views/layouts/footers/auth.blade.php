<footer class="footer pt-0">
    @include('layouts.footers.nav')
</footer>