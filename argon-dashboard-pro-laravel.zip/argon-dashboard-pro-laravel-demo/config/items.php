<?php

return [
    'statuses' => [
        'published' => 'Published',
        'draft' => 'Draft',
        'archive' => 'Archive'
    ],

    'options' => [
        0 => 'First',
        1 => 'Second',
        2 => 'Third'
    ]
];
