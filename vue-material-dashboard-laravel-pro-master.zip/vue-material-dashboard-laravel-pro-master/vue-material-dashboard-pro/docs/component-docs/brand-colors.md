# Brand Colors

1. You can find the colors in `assets/scss/md/_variables.scss` starting with line 28 where is the primary color set: `$brand-primary: $purple !default;`.

2. All the possible colors are in `assets/scss/md/_colors.scss`.
