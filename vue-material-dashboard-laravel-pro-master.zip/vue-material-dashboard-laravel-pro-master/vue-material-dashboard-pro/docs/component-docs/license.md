# License

Currently, on [Creative Tim](https://www.creative-tim.com/) you can get the products with three types of licenses: MIT License, Personal License or Developer License. All the freebies are licensed to MIT License as default. If you are making a paid purchase, be sure to go through the table with the rights and the guidelines, so you can know what license is the best fit for you (Personal License or Developer License). View the rights table and the description for each license on our [Official License Page](https://www.creative-tim.com/license).
