export const API_KEY = process.env.VUE_APP_API_KEY;
