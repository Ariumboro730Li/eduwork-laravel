# Changelog

All notable changes to `Vue Black Dashboard PRO Laravel`  will be documented in this file.

## Version 1.0.0

### Added
- Vue Black Dashboard PRO
- Login
- Register
- Profile edit
- User CRUD
- Role CRUD
- Tag CRUD
- Category CRUD
- Item CRUD
- User roles & access restrictions

## Version 1.0.1
Compatibility with node.js v16.x LTS