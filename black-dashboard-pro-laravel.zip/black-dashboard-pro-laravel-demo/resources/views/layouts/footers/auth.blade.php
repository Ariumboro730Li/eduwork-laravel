<footer class="footer">
  <div class="container-fluid">
    <ul class="nav">
      <li class="nav-item">
        <a href="https://www.creative-tim.com" class="nav-link">
          {{ __('Creative Tim') }}
        </a>
      </li>
      <li class="nav-item">
        <a href="https://creative-tim.com/presentation" class="nav-link">
          {{ __('About Us') }}
        </a>
      </li>
      <li class="nav-item">
        <a href="http://blog.creative-tim.com" class="nav-link">
          {{ __('Blog') }}
        </a>
      </li>
    </ul>
    <div class="copyright">
      ©
      <script>
        document.write(new Date().getFullYear())
      </script> made with <i class="tim-icons icon-heart-2"></i> by
      <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> and <a href="https://www.updivision.com" target="_blank">UPDIVISION</a> for a better web.
    </div>
  </div>
</footer>