<div class="table-responsive mx-3">
    <table class="table table-flush">
        <thead class="thead-light">
            <tr>
                {{ $head ?? '' }}
            </tr>
        </thead>
        <tbody>
            {{ $body ?? '' }}
        </tbody>
    </table>
</div>