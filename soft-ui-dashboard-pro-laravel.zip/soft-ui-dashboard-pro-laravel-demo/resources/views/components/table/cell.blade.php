<td {{ $attributes }}class="text-xs font-weight-bold align-middle">
    <span class="my-2 text-xs">{{ $slot }}</span>
</td>