<tr>
    {{ $slot }}
</tr>