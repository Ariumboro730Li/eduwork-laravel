<?php

namespace App\Http\Livewire\Dashboard;

use Livewire\Component;

class DashboardDefault extends Component
{
    public function render()
    {
        return view('livewire.dashboard.dashboard-default');
    }
}
