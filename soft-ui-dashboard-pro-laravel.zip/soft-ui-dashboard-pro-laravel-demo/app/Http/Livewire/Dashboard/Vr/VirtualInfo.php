<?php

namespace App\Http\Livewire\Dashboard\Vr;

use Livewire\Component;

class VirtualInfo extends Component
{
    public function render()
    {
        return view('livewire.dashboard.vr.virtual-info');
    }
}
