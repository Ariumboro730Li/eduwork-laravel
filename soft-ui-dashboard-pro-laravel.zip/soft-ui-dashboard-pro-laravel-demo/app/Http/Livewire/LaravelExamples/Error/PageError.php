<?php

namespace App\Http\Livewire\LaravelExamples\Error;

use Livewire\Component;

class PageError extends Component
{
    public function render()
    {
        return view('livewire.laravel-examples.error.page-error');
    }
}
