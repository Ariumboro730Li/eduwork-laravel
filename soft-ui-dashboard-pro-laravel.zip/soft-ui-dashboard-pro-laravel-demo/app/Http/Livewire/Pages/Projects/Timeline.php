<?php

namespace App\Http\Livewire\Pages\Projects;

use Livewire\Component;

class Timeline extends Component
{
    public function render()
    {
        return view('livewire.pages.projects.timeline');
    }
}
