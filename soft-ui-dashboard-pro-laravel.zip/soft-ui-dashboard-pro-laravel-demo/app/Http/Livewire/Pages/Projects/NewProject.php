<?php

namespace App\Http\Livewire\Pages\Projects;

use Livewire\Component;

class NewProject extends Component
{
    public function render()
    {
        return view('livewire.pages.projects.new-project');
    }
}
