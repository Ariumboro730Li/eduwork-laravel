<?php

namespace App\Http\Livewire\Pages\Projects;

use Livewire\Component;

class General extends Component
{
    public function render()
    {
        return view('livewire.pages.projects.general');
    }
}
