<?php

namespace App\Http\Livewire\Pages\Account;

use Livewire\Component;

class Security extends Component
{
    public function render()
    {
        return view('livewire.pages.account.security');
    }
}
