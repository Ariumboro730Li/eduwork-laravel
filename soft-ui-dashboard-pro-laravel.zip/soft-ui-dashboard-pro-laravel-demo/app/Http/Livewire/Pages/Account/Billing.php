<?php

namespace App\Http\Livewire\Pages\Account;

use Livewire\Component;

class Billing extends Component
{
    public function render()
    {
        return view('livewire.pages.account.billing');
    }
}
