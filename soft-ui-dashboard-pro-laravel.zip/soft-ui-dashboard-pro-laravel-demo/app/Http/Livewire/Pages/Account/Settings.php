<?php

namespace App\Http\Livewire\Pages\Account;

use Livewire\Component;

class Settings extends Component
{
     public function render()
    {
        return view('livewire.pages.account.settings');
    }
}
