<?php

namespace App\Http\Livewire\Pages\Users;

use Livewire\Component;

class Reports extends Component
{
    public function render()
    {
        return view('livewire.pages.users.reports');
    }
}
