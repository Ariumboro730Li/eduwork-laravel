<?php

namespace App\Http\Livewire\Pages\Profile;

use Livewire\Component;

class AllProjects extends Component
{
    public function render()
    {
        return view('livewire.pages.profile.all-projects');
    }
}
