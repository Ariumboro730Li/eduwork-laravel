<?php

namespace App\Http\Livewire\Pages\Profile;

use Livewire\Component;

use Illuminate\Support\Facades\Request;

class Overview extends Component
{
    public function render()
    {
        return view('livewire.pages.profile.overview');
    }
}
