<?php

namespace App\Http\Livewire\Ecommerce\Orders;

use Livewire\Component;

class OrderList extends Component
{
    public function render()
    {
        return view('livewire.ecommerce.orders.order-list');
    }
}
