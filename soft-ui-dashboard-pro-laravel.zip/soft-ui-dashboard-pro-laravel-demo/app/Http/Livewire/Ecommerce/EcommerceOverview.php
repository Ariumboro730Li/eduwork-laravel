<?php

namespace App\Http\Livewire\Ecommerce;

use Livewire\Component;

class EcommerceOverview extends Component
{
    public function render()
    {
        return view('livewire.ecommerce.ecommerce-overview');
    }
}
