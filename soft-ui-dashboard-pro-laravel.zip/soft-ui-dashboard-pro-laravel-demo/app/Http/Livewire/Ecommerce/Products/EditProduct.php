<?php

namespace App\Http\Livewire\Ecommerce\Products;

use Livewire\Component;

class EditProduct extends Component
{
    public function render()
    {
        return view('livewire.ecommerce.products.edit-product');
    }
}
