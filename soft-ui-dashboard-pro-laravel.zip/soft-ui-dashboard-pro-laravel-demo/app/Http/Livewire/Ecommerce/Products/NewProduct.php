<?php

namespace App\Http\Livewire\Ecommerce\Products;

use Livewire\Component;

class NewProduct extends Component
{
    public function render()
    {
        return view('livewire.ecommerce.products.new-product');
    }
}
