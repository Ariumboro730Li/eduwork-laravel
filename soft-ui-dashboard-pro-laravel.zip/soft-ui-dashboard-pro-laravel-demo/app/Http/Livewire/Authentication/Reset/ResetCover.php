<?php

namespace App\Http\Livewire\Authentication\Reset;

use Livewire\Component;

class ResetCover extends Component
{
    public function render()
    {
        return view('livewire.authentication.reset.reset-cover');
    }
}
