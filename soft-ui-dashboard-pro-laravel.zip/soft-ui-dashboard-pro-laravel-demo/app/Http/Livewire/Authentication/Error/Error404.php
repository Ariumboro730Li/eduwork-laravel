<?php

namespace App\Http\Livewire\Authentication\Error;

use Livewire\Component;

class Error404 extends Component
{
    public function render()
    {
        return view('livewire.authentication.error.error404');
    }
}
