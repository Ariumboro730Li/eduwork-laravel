<?php

namespace App\Http\Livewire\Authentication\Signup;

use Livewire\Component;

class SignupIllustration extends Component
{
    public function render()
    {
        return view('livewire.authentication.signup.signup-illustration');
    }
}
