<?php

namespace App\Http\Livewire\Authentication\Signup;

use Livewire\Component;

class SignupBasic extends Component
{
    public function render()
    {
        return view('livewire.authentication.signup.signup-basic');
    }
}
