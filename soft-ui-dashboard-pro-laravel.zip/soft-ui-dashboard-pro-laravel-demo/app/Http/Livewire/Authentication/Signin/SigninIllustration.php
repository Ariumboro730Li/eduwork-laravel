<?php

namespace App\Http\Livewire\Authentication\Signin;

use Livewire\Component;

class SigninIllustration extends Component
{
    public function render()
    {
        return view('livewire.authentication.signin.signin-illustration');
    }
}
