<?php

namespace App\Http\Livewire\Authentication\Lock;

use Livewire\Component;

class LockBasic extends Component
{
    public function render()
    {
        return view('livewire.authentication.lock.lock-basic');
    }
}
