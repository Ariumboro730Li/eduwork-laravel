<?php

namespace App\Http\Livewire\Authentication\Lock;

use Livewire\Component;

class LockIllustration extends Component
{
    public function render()
    {
        return view('livewire.authentication.lock.lock-illustration');
    }
}
