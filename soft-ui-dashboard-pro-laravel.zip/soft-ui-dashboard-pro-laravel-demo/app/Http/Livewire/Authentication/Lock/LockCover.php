<?php

namespace App\Http\Livewire\Authentication\Lock;

use Livewire\Component;

class LockCover extends Component
{
    public function render()
    {
        return view('livewire.authentication.lock.lock-cover');
    }
}
