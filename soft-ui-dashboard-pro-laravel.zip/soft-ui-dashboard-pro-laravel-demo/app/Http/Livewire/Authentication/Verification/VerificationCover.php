<?php

namespace App\Http\Livewire\Authentication\Verification;

use Livewire\Component;

class VerificationCover extends Component
{
    public function render()
    {
        return view('livewire.authentication.verification.verification-cover');
    }
}
