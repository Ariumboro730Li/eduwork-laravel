<?php

namespace App\Http\Livewire\Authentication\Verification;

use Livewire\Component;

class VerificationBasic extends Component
{
    public function render()
    {
        return view('livewire.authentication.verification.verification-basic');
    }
}
