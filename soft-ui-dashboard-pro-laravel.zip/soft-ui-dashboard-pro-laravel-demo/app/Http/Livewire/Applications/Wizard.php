<?php

namespace App\Http\Livewire\Applications;

use Livewire\Component;

class Wizard extends Component
{
    public function render()
    {
        return view('livewire.applications.wizard');
    }
}
