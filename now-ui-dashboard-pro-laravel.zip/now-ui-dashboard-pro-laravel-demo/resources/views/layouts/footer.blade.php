<footer class="footer">
  <div class=" container-fluid ">
    <nav>
      <ul>
        <li>
          <a href="https://www.creative-tim.com" target="_blank">
            {{__(" Creative Tim")}}
          </a>
        </li>
        <li>
          <a href="https://presentation.creative-tim.com" target="_blank">
            {{__(" About Us")}}
          </a>
        </li>
        <li>
          <a href="https://blog.creative-tim.com" target="_blank">
            {{__(" Blog")}}
          </a>
        </li>
        <li>
          <a href="https://www.updivision.com" target="_blank">
            {{__(" UPDIVISION")}}</a>
        </li>
      </ul>
    </nav>
    <div class="copyright" id="copyright">
      &copy;
      <script>
        document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
      </script>, {{__(" Designed by")}}
      <a href="https://www.invisionapp.com" target="_blank">{{__(" Invision")}}</a>{{__(" . Coded by")}}
      <a href="https://www.creative-tim.com" target="_blank">{{__(" Creative Tim ")}}</a>&
      <a href="https://www.updivision.com" target="_blank">{{__(" UPDIVISION")}}</a>
    </div>
  </div>
</footer>