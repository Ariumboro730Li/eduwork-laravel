<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../../now/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../../now/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Now UI Dashboard PRO by Creative Tim
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <!-- CSS Files -->
  <link rel="stylesheet" href="https://cdn.rtlcss.com/bootstrap/v4.0.0/css/bootstrap.min.css" integrity="sha384-P4uhUIGk/q1gaD/NdgkBIl3a6QywJjlsFJFk7SPRdruoGddvRVSwv5qFnvZ73cpz" crossorigin="anonymous">
  <link href="../../now/css/now-ui-dashboard.css?v=1.4.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../../now/demo/demo.css" rel="stylesheet" />
</head>

<body class="rtl sidebar-mini rtl-active">
  <div class="wrapper ">
    <div class="sidebar" data-color="orange">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-mini">
          ط م
        </a>
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          توقيت الإبداعية
        </a>
        <div class="navbar-minimize">
          <button id="minimizeSidebar" class="btn btn-simple btn-icon btn-neutral btn-round">
            <i class="now-ui-icons text_align-center visible-on-sidebar-regular"></i>
            <i class="now-ui-icons design_bullet-list-67 visible-on-sidebar-mini"></i>
          </button>
        </div>
      </div>
      <div class="sidebar-wrapper" id="sidebar-wrapper">
        <div class="user">
          <div class="photo">
            <img src="../assets/img/james.jpg" />
          </div>
          <div class="info">
            <a data-toggle="collapse" href="#collapseExample" class="collapsed">
              <span>
                جيمس اموس
                <b class="caret"></b>
              </span>
            </a>
            <div class="clearfix"></div>
            <div class="collapse" id="collapseExample">
              <ul class="nav">
                <li>
                  <a href="{{ route('profile.edit') }}">
                    <span class="sidebar-mini-icon">مع</span>
                    <span class="sidebar-normal">ملفي</span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('profile.edit') }}">
                    <span class="sidebar-mini-icon">هوع</span>
                    <span class="sidebar-normal">تعديل الملف الشخصي</span>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <span class="sidebar-mini-icon">و</span>
                    <span class="sidebar-normal">إعدادات</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <ul class="nav">
          <li>
            <a href="{{ route('home') }}">
              <i class="now-ui-icons design_app"></i>
              <p>لوحة القيادةة</p>
            </a>
          </li>
          <li class="active">
            <a data-toggle="collapse" href="#pagesExamples">
              <i class="now-ui-icons design_image"></i>
              <p>
                صفحات
                <b class="caret"></b>
              </p>
            </a>
            <div class="collapse  show " id="pagesExamples">
              <ul class="nav">
                <li class="active">
                  <a href="{{ route('page.index','support') }}">
                    <span class="sidebar-mini-icon">صو</span>
                    <span class="sidebar-normal"> دعم رتل </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','timeline') }}">
                    <span class="sidebar-mini-icon">ر</span>
                    <span class="sidebar-normal"> الجدول الزمني </span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <a data-toggle="collapse" href="#componentsExamples">
              <i class="now-ui-icons education_atom"></i>
              <p>
                المكونات
                <b class="caret"></b>
              </p>
            </a>
            <div class="collapse " id="componentsExamples">
              <ul class="nav">
                <li>
                  <a href="{{ route('page.index','buttons') }}">
                    <span class="sidebar-mini-icon">بت</span>
                    <span class="sidebar-normal"> وصفتت </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','grid') }}">
                    <span class="sidebar-mini-icon">زو</span>
                    <span class="sidebar-normal"> نظام الشبكةو </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','panels') }}">
                    <span class="sidebar-mini-icon">ع</span>
                    <span class="sidebar-normal"> لوحات </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','sweet-alert') }}">
                    <span class="sidebar-mini-icon">ومن</span>
                    <span class="sidebar-normal"> التنبيه الحلو </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','notifications') }}">
                    <span class="sidebar-mini-icon">ن</span>
                    <span class="sidebar-normal"> إخطارات </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','icons') }}">
                    <span class="sidebar-mini-icon">و</span>
                    <span class="sidebar-normal"> الرموز </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','typography') }}">
                    <span class="sidebar-mini-icon">ر</span>
                    <span class="sidebar-normal"> طباعة </span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <a data-toggle="collapse" href="#formsExamples">
              <i class="now-ui-icons files_single-copy-04"></i>
              <p>
                إستمارات
                <b class="caret"></b>
              </p>
            </a>
            <div class="collapse " id="formsExamples">
              <ul class="nav">
                <li>
                  <a href="{{ route('page.index','regular') }}">
                    <span class="sidebar-mini-icon">صو</span>
                    <span class="sidebar-normal"> أشكال منتظمة </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','extended') }}">
                    <span class="sidebar-mini-icon">هوو</span>
                    <span class="sidebar-normal"> أشكال موسعة </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','validation') }}">
                    <span class="sidebar-mini-icon">تو</span>
                    <span class="sidebar-normal"> نماذج التحقق </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','wizard') }}">
                    <span class="sidebar-mini-icon">ث</span>
                    <span class="sidebar-normal"> ساحر </span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <a data-toggle="collapse" href="#tablesExamples">
              <i class="now-ui-icons design_bullet-list-67"></i>
              <p>
                الجداول
                <b class="caret"></b>
              </p>
            </a>
            <div class="collapse " id="tablesExamples">
              <ul class="nav">
                <li>
                  <a href="{{ route('page.index','regulart') }}">
                    <span class="sidebar-mini-icon">صر</span>
                    <span class="sidebar-normal"> الجداول العادية </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','extendedt') }}">
                    <span class="sidebar-mini-icon">هور</span>
                    <span class="sidebar-normal"> الجداول الموسعة </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','datatables') }}">
                    <span class="sidebar-mini-icon">در</span>
                    <span class="sidebar-normal"> جداول البيانات صافي </span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <a data-toggle="collapse" href="#mapsExamples">
              <i class="now-ui-icons location_pin"></i>
              <p>
                خرائط
                <b class="caret"></b>
              </p>
            </a>
            <div class="collapse " id="mapsExamples">
              <ul class="nav">
                <li>
                  <a href="{{ route('page.index','google') }}">
                    <span class="sidebar-mini-icon">زم</span>
                    <span class="sidebar-normal"> خرائط جوجل </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','fullscreen') }}">
                    <span class="sidebar-mini-icon">ووم</span>
                    <span class="sidebar-normal"> خريطة كاملة الشاشة </span>
                  </a>
                </li>
                <li>
                  <a href="{{ route('page.index','vector') }}">
                    <span class="sidebar-mini-icon">تم</span>
                    <span class="sidebar-normal"> سهم التوجيه، الخريطة </span>
                  </a>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <a href="{{ route('page.index','widgets') }}">
              <i class="now-ui-icons objects_diamond"></i>
              <p>الحاجيات</p>
            </a>
          </li>
          <li>
            <a href="{{ route('page.index','charts') }}">
              <i class="now-ui-icons business_chart-pie-36"></i>
              <p>الرسوم البيانية</p>
            </a>
          </li>
          <li>
            <a href="{{ route('page.index','calendar') }}">
              <i class="now-ui-icons media-1_album"></i>
              <p>التقويم</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel" id="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="#pablo"> وحة القيادة</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form>
              <div class="input-group no-border">
                <input type="text" value="" class="form-control" placeholder="Search...">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <i class="now-ui-icons ui-1_zoom-bold"></i>
                  </div>
                </div>
              </div>
            </form>
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="#pablo">
                  <i class="now-ui-icons media-2_sound-wave"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Stats</span>
                  </p>
                </a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="now-ui-icons location_world"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Some Actions</span>
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#pablo">
                  <i class="now-ui-icons users_single-02"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Account</span>
                  </p>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="panel-header">
      </div>
      <div class="content">
        <div class="content">
          <div class="row">
            <div class="col-lg-3 col-sm-6">
              <div class="card card-stats">
                <div class="card-body ">
                  <div class="statistics statistics-horizontal">
                    <div class="info info-horizontal">
                      <div class="row">
                        <div class="col-7 text-right">
                          <h3 class="info-title">1058</h3>
                          <h6 class="stats-title">رسائل</h6>
                        </div>
                        <div class="col-5">
                          <div class="icon icon-primary icon-circle">
                            <i class="now-ui-icons ui-2_chat-round"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="card-footer ">
                  <div class="stats">
                    <i class="now-ui-icons arrows-1_refresh-69"></i> تحديث الان
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6">
              <div class="card card-stats">
                <div class="card-body ">
                  <div class="statistics statistics-horizontal">
                    <div class="info info-horizontal">
                      <div class="row">
                        <div class="col-7 text-right">
                          <h3 class="info-title">
                            <span>$</span>23,685</h3>
                          <h6 class="stats-title">الوديعة</h6>
                        </div>
                        <div class="col-5">
                          <div class="icon icon-warning icon-circle">
                            <i class="now-ui-icons business_bank"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="card-footer ">
                  <div class="stats">
                    <i class="now-ui-icons ui-1_calendar-60"></i> الاسبوع الماضى
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6">
              <div class="card card-stats">
                <div class="card-body ">
                  <div class="statistics statistics-horizontal">
                    <div class="info info-horizontal">
                      <div class="row">
                        <div class="col-7 text-right">
                          <h3 class="info-title">364</h3>
                          <h6 class="stats-title">لاعبين</h6>
                        </div>
                        <div class="col-5">
                          <div class="icon icon-danger icon-circle">
                            <i class="now-ui-icons sport_user-run"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="card-footer ">
                  <div class="stats">
                    <i class="now-ui-icons ui-2_time-alarm"></i> في الساعة الماضية
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6">
              <div class="card card-stats">
                <div class="card-body ">
                  <div class="statistics statistics-horizontal">
                    <div class="info info-horizontal">
                      <div class="row">
                        <div class="col-7 text-right">
                          <h3 class="info-title">+83K</h3>
                          <h6 class="stats-title">متابعون</h6>
                        </div>
                        <div class="col-5">
                          <div class="icon icon-info icon-circle">
                            <i class="now-ui-icons ui-2_favourite-28"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="card-footer ">
                  <div class="stats">
                    <i class="now-ui-icons arrows-1_refresh-69"></i> تحديث الان
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-6 col-md-12 text-center">
              <div class="card card-contributions">
                <div class="card-body ">
                  <h1 class="card-title">3,521</h1>
                  <h3 class="card-category">مجموع المساهمات العامة</h3>
                  <p class="card-description">بعد نجاح ناجح لمدة عامين ، سنقوم بتغيير طريقة عمل المساهمات.</p>
                </div>
                <hr>
                <div class="card-footer">
                  <div class="row">
                    <div class="col-6">
                      <div class="card-stats justify-content-center">
                        <input type="checkbox" name="checkbox" class="bootstrap-switch" data-on-label="ON" data-off-label="OFF" checked>
                        <span>جميع المساهمات العامة</span>
                      </div>
                    </div>
                    <div class="col-6">
                      <div class="card-stats justify-content-center">
                        <input type="checkbox" name="checkbox" class="bootstrap-switch" data-on-label="ON" data-off-label="OFF">
                        <span>مساهمات الأسبوع </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card card-tasks">
                <div class="card-header ">
                  <h5 class="card-category">تطوير الخلفية</h5>
                  <h4 class="card-title">مهام</h4>
                </div>
                <div class="card-body">
                  <div class="table-full-width table-responsive">
                    <table class="table">
                      <tbody>
                        <tr>
                          <td>
                            <div class="form-check">
                              <label class="form-check-label">
                                <input class="form-check-input" type="checkbox" checked="">
                                <span class="form-check-sign"></span>
                              </label>
                            </div>
                          </td>
                          <td class="img-row">
                            <div class="img-wrapper img-raised">
                              <img src="../assets/img//emilyz.jpg" class="img-raised">
                            </div>
                          </td>
                          <td class="text-left">توقيع عقد "ما يخشاه منظمو المؤتمر؟"</td>
                          <td class="td-actions">
                            <button type="button" rel="tooltip" title="" class="btn btn-info btn-round btn-icon btn-icon-mini btn-neutral" data-original-title="Edit Task">
                              <i class="now-ui-icons ui-2_settings-90"></i>
                            </button>
                            <button type="button" rel="tooltip" title="" class="btn btn-danger btn-round btn-icon btn-icon-mini btn-neutral" data-original-title="Remove">
                              <i class="now-ui-icons ui-1_simple-remove"></i>
                            </button>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="form-check">
                              <label class="form-check-label">
                                <input class="form-check-input" type="checkbox">
                                <span class="form-check-sign"></span>
                              </label>
                            </div>
                          </td>
                          <td class="img-row">
                            <div class="img-wrapper img-raised">
                              <img src="../assets/img//james.jpg" class="img-raised">
                            </div>
                          </td>
                          <td class="text-left">خطوط من الأدب الروسي العظيم؟ أو رسائل البريد الإلكتروني من بلدي بوس؟ </td>
                          <td class="td-actions">
                            <button type="button" rel="tooltip" title="" class="btn btn-info btn-round btn-icon btn-icon-mini btn-neutral" data-original-title="Edit Task">
                              <i class="now-ui-icons ui-2_settings-90"></i>
                            </button>
                            <button type="button" rel="tooltip" title="" class="btn btn-danger btn-round btn-icon btn-icon-mini btn-neutral" data-original-title="Remove">
                              <i class="now-ui-icons ui-1_simple-remove"></i>
                            </button>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="form-check">
                              <label class="form-check-label">
                                <input class="form-check-input" type="checkbox" checked="">
                                <span class="form-check-sign"></span>
                              </label>
                            </div>
                          </td>
                          <td class="img-row">
                            <div class="img-wrapper img-raised">
                              <img src="../assets/img//mike.jpg" class="img-raised">
                            </div>
                          </td>
                          <td class="text-left">مغمورة: بعد مرور عام ، تقييم ما فقد وما تم العثور عليه عندما اجتاحت الأمطار المدمرة مترو ديترويت
                          </td>
                          <td class="td-actions">
                            <button type="button" rel="tooltip" title="" class="btn btn-info btn-round btn-icon btn-icon-mini btn-neutral" data-original-title="Edit Task">
                              <i class="now-ui-icons ui-2_settings-90"></i>
                            </button>
                            <button type="button" rel="tooltip" title="" class="btn btn-danger btn-round btn-icon btn-icon-mini btn-neutral" data-original-title="Remove">
                              <i class="now-ui-icons ui-1_simple-remove"></i>
                            </button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="card-footer ">
                  <hr>
                  <div class="stats">
                    <i class="now-ui-icons loader_refresh spin"></i> تم التحديث منذ 3 دقائق
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card card-timeline card-plain">
                <div class="card-body">
                  <ul class="timeline timeline-simple">
                    <li class="timeline-inverted">
                      <div class="timeline-badge danger">
                        <i class="now-ui-icons objects_planet"></i>
                      </div>
                      <div class="timeline-panel">
                        <div class="timeline-heading">
                          <span class="badge badge-danger">بعض العنوان</span>
                        </div>
                        <div class="timeline-body">
                          <p>قدم أفضل وجبة يوم الأب على الإطلاق. ممتن جدا سعيد جدا حتى المباركة. شكراً لك على صنع عائلتي لقد استمتعنا بالموضوع "المستقبلي" !!! كانت ليلة ممتعة كل ذلك معا ... عرض كاني فظ دائما في الساعة 2 صباحا بيعت من مشاهير مشاهدة </p>
                        </div>
                        <h6>
                          <i class="ti-time"></i> قبل 11 ساعة عبر تويتر
                        </h6>
                      </div>
                    </li>
                    <li class="timeline-inverted">
                      <div class="timeline-badge success">
                        <i class="now-ui-icons shopping_tag-content"></i>
                      </div>
                      <div class="timeline-panel">
                        <div class="timeline-heading">
                          <span class="badge badge-success">واحدة أخرى</span>
                        </div>
                        <div class="timeline-body">
                          <p> أيضًا الإشارة إلى أنه أول ألبوم ينتقل إلى رقم 1 من البث المباشر !!! أنا أحبك إلين وأيضا قاعدة بلدي رقم واحد تصميم أي شيء أفعله من الأحذية إلى الموسيقى إلى المنازل هو أن كيم يجب أن ترغب في ذلك </p>
                        </div>
                      </div>
                    </li>
                    <li class="timeline-inverted">
                      <div class="timeline-badge info">
                        <i class="now-ui-icons shopping_delivery-fast"></i>
                      </div>
                      <div class="timeline-panel">
                        <div class="timeline-heading">
                          <span class="badge badge-info">عنوان آخر</span>
                        </div>
                        <div class="timeline-body">
                          <p>يسمى أنا أفتقد كاني القديم هذا كل ما كان كاني وأنا أحبك مثل كاني يحب كاني مشاهدة مشاهير @ Figueroa و 12 في وسط المدينة LA 11:10 PM</p>
                          <p>ماذا لو قدمت كاني أغنية عن كاني رويير لا تصنع سرير الدب القطبي ولكن الأريكة الدببة القطبية هي قطعة الأثاث المفضلة لدينا التي نملكها. لم يكن أي مجموعة من Kanyes على أهدافه كاني</p>
                          <hr>
                        </div>
                        <div class="timeline-footer">
                          <div class="dropdown">
                            <button type="button" class="btn btn-round btn-info dropdown-toggle" data-toggle="dropdown">
                              <i class="now-ui-icons design_bullet-list-67"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                              <a class="dropdown-item" href="#">عمل</a>
                              <a class="dropdown-item" href="#">إجراء آخر</a>
                              <a class="dropdown-item" href="#">شيء آخر هنا</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="row">
                <div class="col-lg-6">
                  <div class="card card-pricing ">
                    <h6 class="card-category"> حزمة ألفا</h6>
                    <div class="card-body">
                      <div class="card-icon icon-primary ">
                        <i class="now-ui-icons objects_diamond"></i>
                      </div>
                      <h3 class="card-title">69$</h3>
                      <ul>
                        <li>مواد العمل في EPS</li>
                        <li>6 أشهر الوصول إلى المكتبة</li>
                      </ul>
                    </div>
                    <div class="card-footer">
                      <a href="#pablo" class="btn btn-round btn-primary">أضف إلى السلة</a>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="card card-pricing card-plain">
                    <h6 class="card-category"> برافو باك</h6>
                    <div class="card-body">
                      <div class="card-icon icon-warning ">
                        <i class="now-ui-icons media-1_button-power"></i>
                      </div>
                      <h3 class="card-title">10$</h3>
                      <ul>
                        <li>وثائق كاملة</li>
                        <li>مواد العمل في Sketch</li>
                      </ul>
                    </div>
                    <div class="card-footer">
                      <a href="#pablo" class="btn btn-round btn-neutral btn-warning">أضف إلى السلة</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card card-testimonial">
                <div class="card-header card-header-avatar">
                  <a href="#pablo">
                    <img class="img img-raised" src="../assets/img//james.jpg">
                  </a>
                </div>
                <div class="card-body ">
                  <p class="card-description">
                    إن التشبيك في قمة الويب لا يشبه أي مؤتمر تقني أوروبي آخر.
                  </p>
                  <div class="icon icon-primary">
                    <i class="fa fa-quote-right"></i>
                  </div>
                </div>
                <div class="card-footer ">
                  <h4 class="card-title">ألتون بيكر</h4>
                  <p class="category">@altonbecker</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class=" container-fluid ">
          <nav>
            <ul>
              <li>
                <a href="https://www.creative-tim.com">
                  Creative Tim
                </a>
              </li>
              <li>
                <a href="http://presentation.creative-tim.com">
                  About Us
                </a>
              </li>
              <li>
                <a href="http://blog.creative-tim.com">
                  Blog
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright" id="copyright">
            &copy;
            <script>
              document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
            </script>, Designed by
            <a href="https://www.invisionapp.com" target="_blank">Invision</a>. Coded by
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a>.
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="https://cdn.rtlcss.com/bootstrap/v4.0.0/js/bootstrap.min.js" integrity="sha384-54+cucJ4QbVb99v8dcttx/0JRx4FHMmhOWi4W+xrXpKcsKQodCBwAvu3xxkZAwsH" crossorigin="anonymous"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <script src="../assets/js/plugins/moment.min.js"></script>
  <!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
  <script src="../assets/js/plugins/bootstrap-switch.js"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="../assets/js/plugins/sweetalert2.min.js"></script>
  <!-- Forms Validations Plugin -->
  <script src="../assets/js/plugins/jquery.validate.min.js"></script>
  <!--  Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
  <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="../assets/js/plugins/bootstrap-selectpicker.js"></script>
  <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
  <script src="../assets/js/plugins/bootstrap-datetimepicker.js"></script>
  <!--  DataTables.net Plugin, full documentation here: https://datatables.net/    -->
  <script src="../assets/js/plugins/jquery.dataTables.min.js"></script>
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="../assets/js/plugins/bootstrap-tagsinput.js"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="../assets/js/plugins/jasny-bootstrap.min.js"></script>
  <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
  <script src="../assets/js/plugins/fullcalendar.min.js"></script>
  <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
  <script src="../assets/js/plugins/jquery-jvectormap.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="../assets/js/plugins/nouislider.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/now-ui-dashboard.min.js?v=1.4.1" type="text/javascript"></script>
  <!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      demo.checkFullPageBackgroundImage();
    });
  </script>
</body>

</html>